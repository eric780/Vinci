<?php 

echo "yoyoyo, it's Conan!"

?>